# You have to write a code for password login. You set a password, and get a password from user. If the password FROM USER.If the password is matched ,display greeting message,otherwise.display bye bye message.
password = "20021204"
password_input = input("Please enter the password:")
if password_input ==password:
    print("welcome Joanna.You are Awesome.")
else:
    print("Bye bye! Incorrect password.")