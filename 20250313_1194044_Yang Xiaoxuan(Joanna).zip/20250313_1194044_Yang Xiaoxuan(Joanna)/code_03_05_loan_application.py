# This program determine whether you will accept loan aplication or reject based on annual dalary and year of work.annual salary >=50,000 and work year >= 5
# Set the acceptance criteria
criteria_annual_salary =50000
criteria_year_of_work = 5
# Get input of salary and working year
annual_salary = int(input("Please enter your annual salary: "))
year_of_work= int(input("Please enter your year of work: "))
# Determine whether you will accept or reject ,if the condition is fulfilled,then display"Congratulation, your application has accepted“, otherwise,display "Sorry,your application had rejected"
if annual_salary >= criteria_annual_dalary and year_of_work >=criteria_year_or_work
    Print("Congratulation, your application has accepted")
# Otherwise ,display "Sorry,your application had rejected"
else
    Print("Sorry,your application had rejected")