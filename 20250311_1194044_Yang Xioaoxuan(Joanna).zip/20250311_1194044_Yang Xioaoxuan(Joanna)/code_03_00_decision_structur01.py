sales =loat(input("What is your sales total?"))
if sales > 50000
   bonus= 500
   commisiion_rate = 0.12
   print(f'Congratualtion, you have extra{bonus:,.2f}yuan and your commission rate has upgraded to {commission_rate:0%}')
else:
   print("sorry no bonus")