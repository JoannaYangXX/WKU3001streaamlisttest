print('I will displahy the odd numbers 1 through 9.')
for num in [1,3,5,7,9]:
    print(num)
print("------")


for num in range(5):
    print(num)
print("------")


for num in range(1, 6):
    print(num)
print("------")


for num in range(1,2,6):
    print(num)
print("------")

for message in range(1):
    print("lalala")